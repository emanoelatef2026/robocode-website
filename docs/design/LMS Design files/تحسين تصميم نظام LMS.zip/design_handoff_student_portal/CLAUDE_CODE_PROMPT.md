# Prompt for Claude Code

Copy this entire prompt and paste it into Claude Code after navigating to the robocode_website directory.

---

## PROMPT (paste below this line)

I have a design handoff package for the **Student Portal** of the RoboCode LMS. 

The design is called **"Bright Ops + Light Gamification"** — a clean SaaS layout with streak counters, XP points, and badges as motivational elements.

**Reference files are in: `../design_handoff_student_portal/`**

Before writing any code:
1. Read `../design_handoff_student_portal/README.md` — this is the complete design spec
2. Open `../design_handoff_student_portal/Student Dashboard Final.dc.html` in a browser to see the visual reference for the dashboard
3. Open `../design_handoff_student_portal/Student Attendance.dc.html` to see the attendance page reference

---

## Codebase context
- Framework: Next.js 14 (App Router), TypeScript, Tailwind CSS
- Student portal pages: `app/portal/student/`
- Shell component: `components/portal/student/StudentShell.tsx`
- Existing data queries are in each page's `page.tsx` — **do not change data fetching, only the UI**

---

## What to implement (in this order)

### Sprint 1 — Shell
Update `components/portal/student/StudentShell.tsx`:
- Sidebar: 200px fixed, navy bg, XP mini-widget above user footer (see README §Shell)
- Header: greeting h1 + date, streak chip (🔥 + Orbitron number), rank chip (desktop), bell with badge
- Mobile bottom nav: 5 items (Dashboard / Sessions / Assignments / Attendance / Certificates)

### Sprint 2 — Dashboard
Update `app/portal/student/page.tsx`:
- Next Session hero card (dark navy gradient, circuit SVG, countdown, Join button)
- 3 KPI cards (Attendance %, Homework %, Points) with sparklines
- Two-column layout: Assignments list (left) + Attendance ring + Leaderboard + Certificate card (right)

### Sprint 3 — Attendance
Update `app/portal/student/attendance/page.tsx` (or equivalent):
- 4 KPI cards
- Donut chart (conic-gradient, no library needed) + Session calendar heatmap
- Session history list with filter pills (All / Present / Late / Absent) + XP badges
- Streak card (dark) + Tips cards

### Sprint 4 — Assignments
Update assignments page:
- Severity rail per row (4px colored strip by urgency)
- XP badge on each assignment
- Action buttons per status

### Sprints 5–7 — Sessions / Certificates / Portfolio
Follow README specs for each.

### Sprint 8 — RTL + Mobile audit
See README §RTL Rules and §Responsive Breakpoints.

---

## Design tokens
All colors, radii, shadows, and typography rules are in README §Design Tokens.
Key rule: **all numeric display values use font-family: 'Orbitron'** (already loaded).

---

## Important rules
1. **Never change data fetching** — only the JSX/TSX UI layer
2. **Use logical CSS** everywhere (ps/pe/ms/me/rounded-s/rounded-e) — RTL must work
3. **No new libraries** — no chart library, no icon library; use inline SVG + conic-gradient
4. **Keep all existing `<Suspense>` wrappers** — just update the skeleton heights to match new card sizes
5. Work **sprint by sprint** — show me the result after each sprint before continuing

Start with Sprint 1. Show me the updated `StudentShell.tsx` first.
