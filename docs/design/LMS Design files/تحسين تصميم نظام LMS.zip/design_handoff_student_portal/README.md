# Design Handoff: Student Portal — Full Redesign
## Bright Ops + Light Gamification System

---

## Overview
A full redesign of the Student Portal inside the RoboCode School LMS. The design direction is **"Bright Ops + Light Gamification"** — a clean, professional SaaS layout (consistent with the Team Leader dashboard) with carefully placed gamification elements (streaks, XP, leaderboard, badges) that motivate students without feeling childish.

The target audience is mixed (ages 8–18), so the gamification is subtle: it lives in chips and sidebars, not as the primary layout metaphor.

---

## Reference Files (open these before touching any code)
All files are in this handoff folder:
- `TL Dashboard Redesign.dc.html` — Team Leader dashboard (the visual system anchor)
- `Student Dashboard Final.dc.html` — Student dashboard (the primary reference)
- `Student Attendance.dc.html` — Attendance page (second reference)

**Open each file in a browser** — they are fully interactive. Toggle EN/AR and Desktop/Mobile using the controls.

---

## Design Tokens

### Colors (add to `app/globals.css` :root if not already there)
```css
/* Core palette */
--navy:          #0B1F3A;   /* sidebar, primary CTAs, dark hero */
--navy-light:    #163560;   /* sidebar hover, gradient end */
--orange:        #FF8A1F;   /* active nav, CTA buttons, streak */
--orange-soft:   #FFB15A;   /* XP bar, level text, secondary orange */
--orange-bg:     #FFF7E6;   /* streak chip bg, XP badge bg */
--orange-border: #f6e3c4;   /* streak chip border */

/* Status */
--green:         #10B981;   /* present, healthy, success */
--green-bg:      #E7F8EE;
--green-dark:    #15803D;
--amber:         #F59E0B;   /* late, warning */
--amber-bg:      #FFF7E6;
--amber-dark:    #B45309;
--red:           #EF4444;   /* absent, overdue, danger */
--red-bg:        #FEF2F2;
--red-dark:      #DC2626;
--sky:           #38BDF8;   /* sessions, info, circuit accent */
--sky-bg:        #E6F6FE;

/* Neutrals */
--bg-page:       #F0F4F8;   /* page background */
--bg-card:       #FFFFFF;   /* card background */
--bg-input:      #F1F5F9;   /* inputs, secondary bg */
--border:        #E2E8F0;   /* default border */
--border-soft:   #e7ebf1;   /* card borders */
--text:          #0B1F3A;   /* primary text */
--text-2:        #334155;   /* secondary */
--muted:         #64748B;   /* labels, meta */
--subtle:        #94A3B8;   /* placeholder, light meta */
```

### Typography
```
Body:      Poppins (already via next/font)
Arabic:    Cairo  (already loaded, applied when dir=rtl)
Display:   Orbitron — ALL numeric values (KPI numbers, XP, streak count, countdown timers)
           font-family: 'Orbitron', sans-serif; font-weight: 700/800
```

### Spacing & Radius
```
Page padding:   px-7 py-6 (desktop) / px-4 py-4 (mobile)
Card:           rounded-2xl (16px) — standard
Card inner:     rounded-xl (12px) — nested elements
Badge/chip:     rounded-full
Button:         rounded-[9px] or rounded-[11px]
Sidebar:        rounded-[9px] per nav item
Gap (grid):     gap-4 (13px) standard / gap-[18px] between sections
```

### Shadows
```
Card:    shadow-sm  (default)  → shadow-md (hover, transition-all duration-150)
Hero:    0 18px 50px rgba(11,31,58,.16)
```

---

## Shell Components

### 1. StudentShell (Sidebar + Header)
**File:** `components/portal/student/StudentShell.tsx`

#### Sidebar (desktop only, fixed, 200px width)
```
Background:    bg-[#0B1F3A]
Padding:       px-3 py-[18px]
Logo:          30×30px bg-white rounded-[8px] chip + "ROBOCODE" Orbitron 700 12px

Section label: 8.5px / 700 / tracking-[.2em] / text-white/25 / uppercase

Nav items:
  Container:   flex items-center gap-[10px] px-[10px] py-[9px] rounded-[9px] mb-0.5
  Active:      bg-[rgba(255,138,31,.15)] text-[#FF8A1F]
  Inactive:    text-white/52
  Badge dot:   bg-[#EF4444] text-white text-[9px] font-bold min-w-[17px] h-[17px]
               rounded-full flex items-center justify-center ml-auto

XP sidebar widget (above user footer):
  bg-white/5 rounded-[10px] px-[10px] py-[10px] mb-[10px]
  Level + XP: "LV.5" Orbitron 700 10px text-[#FFB15A]  |  "1,240 XP" right
  Bar: h-[5px] bg-white/10 rounded-sm → fill gradient (#FF8A1F → #FFD166 → #FF8A1F)
       animated: background-size:200%; animation: xpglow 3s ease infinite
  Sub: "260 XP to next level" 9px text-white/30

User footer:
  Avatar: 30×30px rounded-full gradient (135deg, #FF8A1F → #0B1F3A) initials
  Name:   11.5px/600/white
  Role:   9.5px/text-white/40
```

#### Top Header
```
bg-white border-b border-[#e9edf3] sticky top-0 z-40
Padding: px-7 py-[14px]

LEFT:
  h1: "Hey, [name] 👋" — 17px/800/--navy
  p:  date + group — 11.5px/--muted

RIGHT (desktop only):
  Streak chip:   bg-[#FFF7E6] border border-[#f6e3c4] rounded-[10px] px-3 py-[7px]
                 🔥 icon + Orbitron 700 14px text-[#B45309] + "DAY STREAK" 9px
  Rank chip:     bg-[#0B1F3A] rounded-[10px] px-3 py-[7px]
                 🏆 icon + Orbitron 700 14px text-[#FFB15A] + "IN GROUP" 9px
  Bell button:   38×38px rounded-[10px] border border-[#e4e9f0]
                 Red dot badge (7px) if unread > 0

MOBILE:
  Hamburger button 32×32px bg-[#F1F5F9] rounded-[8px] (opens drawer)
  Only streak chip, no rank chip
```

#### Mobile Bottom Nav
```
bg-white border-t border-[#e9edf3] fixed bottom-0 left-0 right-0 pb-3 pt-2 z-50
5 items: Dashboard / Sessions / Assignments / Attendance / Certificates
Active: icon bg-[#FFF1E2] text-[#FF8A1F] / Inactive: text-[#94A3B8]
```

---

## Gamification Elements (global, apply everywhere)

### XP Badge (on assignments, sessions)
```tsx
<div className="inline-flex items-center gap-[3px] bg-[#FFF7E6] rounded-full px-2 py-0.5">
  <span className="text-[9px]">⭐</span>
  <span className="text-[9.5px] font-bold text-[#B45309]">+150 XP</span>
</div>
```

### Streak Chip (in header)
```tsx
<div className="flex items-center gap-[7px] bg-[#FFF7E6] border border-[#f6e3c4] rounded-[10px] px-3 py-[7px]">
  <span>🔥</span>
  <div>
    <div className="font-['Orbitron'] font-bold text-[14px] text-[#B45309] leading-none">{streak}</div>
    <div className="text-[9px] text-[#B45309] font-semibold tracking-[.05em]">DAY STREAK</div>
  </div>
</div>
```

### Status Badges
```
Present:  bg-[#E7F8EE] text-[#15803D]
Late:     bg-[#FFF7E6] text-[#B45309]
Absent:   bg-[#FEF2F2] text-[#DC2626]
Pending:  bg-[#F1F5F9] text-[#475569]
Overdue:  bg-[#FEF2F2] text-[#DC2626]
Healthy:  bg-[#E7F8EE] text-[#15803D]
Watch:    bg-[#FFF7E6] text-[#B45309]
```

---

## Page-by-Page Specs

### 1. Dashboard (reference: Student Dashboard Final.dc.html)

**Layout:** Sidebar + header + scrollable body

**Sections (top to bottom):**

#### Next Session Hero Card
```
bg-gradient-to-br from-[#0B1F3A] to-[#163560] rounded-[18px] p-5 overflow-hidden
SVG circuit trace decoration (opacity .1, stroke #38BDF8)

LEFT: pulsing "NEXT SESSION" chip (bg-sky/18 border-sky/30) + session title Orbitron 700 19px +
      instructor/type/time meta 12px text-[#8fa6c4]

RIGHT: countdown timer Orbitron 800 30px text-[#FF8A1F] in frosted box +
       "Join Session" button bg-[#FF8A1F] text-white font-bold rounded-[11px] px-[22px] py-[13px]
```

#### KPI Row (3 cards)
```
grid grid-cols-3 (desktop) / grid-cols-1 (mobile), gap-[13px]
Each card: bg-white border border-[#e7ebf1] rounded-[15px] p-4
  Left: 40×40px rounded-[12px] icon bubble + label 10.5px + Orbitron 700 22px value
  Right: 5-bar sparkline (5px wide bars, rounded-t)
```

#### Two-column body
```
grid grid-cols-[1.55fr_1fr] (desktop) / grid-cols-1 (mobile), gap-[18px]

LEFT:
  - Assignments card (list with emoji, XP badge, action button)
  - Learning Path card (3 courses with emoji icon + progress bar)

RIGHT:
  - Attendance ring card (90px donut, legend, present/absent counts)
  - Group Leaderboard card (5 rows, highlighted "you" row, motivation strip)
  - Certificate card (dark navy, orange download button)
```

---

### 2. Attendance (reference: Student Attendance.dc.html)

**Layout:** Same shell

**Sections:**

#### KPI Row (4 cards)
Present count / Late count / Absence count / Streak — each with emoji icon bubble + Orbitron value + status badge

#### Donut + Calendar (2-col on desktop)
```
LEFT — Donut summary (280px):
  130×130px donut: conic-gradient(#10B981 0 Xdeg, #F59E0B Xdeg Ydeg, #EF4444 Ydeg 360deg)
  Center: Orbitron 800 26px rate + "present" label
  Legend: 4 rows (present/late/absent/excused) with count + percentage
  Goal bar: h-[8px] gradient bar + "Goal achieved 🎉" chip if met

RIGHT — Session Calendar:
  Month header with ‹ › navigation
  Day labels row (7 cols)
  Date grid (7 cols × 5 rows): each cell is aspect-ratio:1 rounded-[6px]
    Present day:  bg-[#D1FAE5] text-[#15803D]
    Late day:     bg-[#FEF3C7] text-[#92400E]
    Absent day:   bg-[#FEE2E2] text-[#991B1B]
    Today:        bg-[#0B1F3A] text-white
    No session:   bg-[#F8FAFC] text-[#94A3B8]
  Sessions have a 4px dot indicator at the bottom
  Legend: 4 color swatches
```

#### Session History + Right Rail (2-col on desktop)
```
LEFT — Session History:
  Header with filter pills: All / Present / Late / Absent
  Each row: emoji icon (36×36 colored bg) + title + instructor/date + duration (desktop only) + status badge + XP badge

RIGHT:
  Streak card (dark navy, hex pattern, Orbitron 46px streak number, 7-dot bar, badge progress)
  Tips cards (2): contextual encouragement + makeup class offer
```

---

### 3. Assignments

**Key elements to implement:**
```
- 3 KPI cards: Pending / Overdue / Completed this month
- Assignment list with:
    Severity rail (4px colored left strip): red=overdue, amber=due-soon, green=on-track, sky=upcoming
    Emoji icon (🤖📝🎨📋) in colored bubble
    Title + course name
    Due date (red if overdue, amber if <2 days)
    XP badge (⭐ +150 XP)
    Action button (Start / Continue / Open / Review)
- Empty state if no assignments (SectionEmptyState pattern)
```

---

### 4. Sessions (Upcoming & History)

**Key elements:**
```
- Hero "Next Session" card (same as dashboard)
- Upcoming sessions list:
    Each: session title + course + instructor + date/time chip + "Join" / "View Materials" button
    Countdown if within 24h
- Past sessions: same as attendance session log with status badge + XP earned
```

---

### 5. Certificates

**Key elements:**
```
- Certificate cards (dark navy with orange accents):
    Title + emoji + "Earned on" date + level badge + Download button
- Locked certificates (grayscale, progress bar, "X sessions to unlock")
- Stats: total earned / in progress
```

---

### 6. Portfolio / Projects

**Key elements:**
```
- Project cards: thumbnail placeholder + title + course + date + "View" button
- Tags: Robotics / Coding / Electronics
```

---

## Interaction Patterns

| Interaction | Behaviour |
|---|---|
| Card hover | border → border-[#CBD5E1] + shadow-md, transition-all duration-150 |
| Button hover | opacity-90 |
| Nav item active | bg-[rgba(255,138,31,.15)] text-[#FF8A1F] |
| Status badge | Never interactive — display only |
| XP gain (submit assignment) | Toast: "⭐ +150 XP earned!" — amber bg |

---

## RTL / Arabic Rules
- Always use logical CSS: ps/pe (padding-inline-start/end), ms/me (margin-inline), rounded-s/e
- Never text-right → use text-end
- Never left:/right: for layout → use start:/end: or inset-inline-start/end
- Severity rails on list items: always inset-inline-start-0
- Cairo font auto-applied on body when dir=rtl (already in codebase)

---

## Responsive Breakpoints
| Element | Mobile (<768px) | Desktop (≥768px) |
|---|---|---|
| Sidebar | Hidden | Fixed 200px |
| Bottom nav | Shown (5 items) | Hidden |
| Header greeting | Hidden | Shown |
| Rank chip | Hidden | Shown |
| Search bar | Hidden | Shown |
| KPI grid | 2 cols | 3–4 cols |
| Two-col layout | Single col | 2-col |
| Duration in session log | Hidden | Shown |

---

## Assets
- Logo: `/public/logo.png` — on dark bg: brightness-0 invert; on white: as-is; inside 30×30px white chip on sidebar
- Icons: Use Heroicons inline SVG (already in codebase via TLSidebar IC object pattern)
- No new icon library needed

---

## Implementation Order
1. **StudentShell** — sidebar + header + mobile nav (shared across all pages)
2. **Dashboard** page — KPI row + Next Session hero + 2-col layout
3. **Attendance** page — KPI + donut + calendar + session log
4. **Assignments** page
5. **Sessions** page
6. **Certificates** page
7. **Portfolio** page
8. **RTL + mobile audit** across all pages
